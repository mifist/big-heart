<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['standalone'] = true;
